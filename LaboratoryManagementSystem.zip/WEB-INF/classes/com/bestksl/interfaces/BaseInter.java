package com.bestksl.interfaces;

import java.io.Serializable;

public interface BaseInter {
	public void add(Serializable object);
}
