package com.bestksl.util;

class test {
	
	public static void main(String[] args) {
		
	}
}