package com.bestksl.action;

import com.opensymphony.xwork2.ActionSupport;

public class IndexAction extends ActionSupport {

	public String execute() {
		return SUCCESS;
	}
}
