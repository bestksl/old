package com.bestksl.action;

import com.opensymphony.xwork2.ActionSupport;

public class FileManageAction extends ActionSupport {

	public String toPaper() {

		return "topaper";
	}

	public String toPatent() {

		return "topatent";
	}

	public String toAchievement() {

		return "toachievement";
	}

	public String toBook() {

		return "tobook";
	}

	public String toFileManage() {
		return "tofilemanage";
	}

	public String toLiterature() {

		return "toliterature";
	}
}
